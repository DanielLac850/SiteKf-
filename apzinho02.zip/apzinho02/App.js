import * as React from 'react';
import {View,Text,StyleSheet,Image,ScrollView} from 'react-native';

export default function App(){
  return(
    <View style={estilo.container}>
      <Text style={estilo.titulo}> Melhores Estilos de Café </Text>
      <Text style={estilo.frase}> Quentinho para esquentar sua vida  </Text>

      <ScrollView style={estilo.fotos}>

      <Image style={estilo.img} source={require("./assets/café.jpg")}/>
      <Text style={estilo.legenda}> Café (comum) </Text>
      <Image style={estilo.img} source={require("./assets/cafégelado.jpg")}/>
      <Text style={estilo.legenda}> Café Gelado </Text>
      <Image style={estilo.img} source={require("./assets/capuccino.jpg")}/>
      <Text style={estilo.legenda}> Capuccino </Text>
      <Image style={estilo.img} source={require("./assets/achocolatado.jpg")}/>
      <Text style={estilo.legenda}> Café com Leite </Text>
      <Image style={estilo.img} source={require("./assets/lattecafé.jpg")}/>
      <Text style={estilo.legenda}> Latte </Text>
      <Image style={estilo.img} source={require("./assets/macchiato.jpg")}/>
      <Text style={estilo.legenda}> Macchiato </Text>
      <Image style={estilo.img} source={require("./assets/frape.jpg")}/>
      <Text style={estilo.legenda}> Frape </Text>
      <Image style={estilo.img} source={require("./assets/irish.jpg")}/>
      <Text style={estilo.legenda}> Irish </Text>
      <Image style={estilo.img} source={require("./assets/mocha.jpg")}/>
      <Text style={estilo.legenda}> Mocha </Text>

      </ScrollView>

    </View>
  );
}

const estilo = StyleSheet.create({
container:{
  flex:1,
  backgroundColor:'#7F5031',
  alignItems:'center',

},
titulo:{
  fontFamily1:'Bebas Neue',
  textAlign:'center',
  fontSize:25,
  color:'white',
  fontWeight:'bold',
  marginTop:45,
  marginBottom:10,

},
frase:{
  fontFamily:'Playfair Display',
  fontSize:15,
  color:'white',
  marginBottom:20,

},
img:{
  borderRadius:15,
  width:350,
  height:200,

},
legenda:{
  textAlign:'center',
  color:'white',
  fontWeight:'bold',
  marginBottom:20,

},
fotos:{
  alignItems: 'center',
}
});
